﻿using System;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Drawing.Text;
using System.Windows.Forms;

namespace NenyooLaunchpad
{
	// Token: 0x02000006 RID: 6
	public class ThemedControl : Control
	{
		// Token: 0x17000001 RID: 1
		// (get) Token: 0x0600000D RID: 13 RVA: 0x000023D0 File Offset: 0x000005D0
		// (set) Token: 0x0600000E RID: 14 RVA: 0x000023D8 File Offset: 0x000005D8
		public ThemedControl.MouseState State { get; set; }

		// Token: 0x17000002 RID: 2
		// (get) Token: 0x0600000F RID: 15 RVA: 0x000023E1 File Offset: 0x000005E1
		// (set) Token: 0x06000010 RID: 16 RVA: 0x000023E9 File Offset: 0x000005E9
		public int CornerRadius
		{
			get
			{
				return this._CornerRadius;
			}
			set
			{
				this._CornerRadius = value;
				base.Invalidate();
			}
		}

		// Token: 0x17000003 RID: 3
		// (get) Token: 0x06000011 RID: 17 RVA: 0x000023F8 File Offset: 0x000005F8
		// (set) Token: 0x06000012 RID: 18 RVA: 0x00002400 File Offset: 0x00000600
		public float Rotation
		{
			get
			{
				return this._Rotation;
			}
			set
			{
				this._Rotation = value;
				base.Invalidate();
			}
		}

		// Token: 0x17000004 RID: 4
		// (get) Token: 0x06000013 RID: 19 RVA: 0x0000240F File Offset: 0x0000060F
		// (set) Token: 0x06000014 RID: 20 RVA: 0x00002417 File Offset: 0x00000617
		public Color PrimaryColor
		{
			get
			{
				return this._primaryColor;
			}
			set
			{
				this._primaryColor = value;
				base.Invalidate();
			}
		}

		// Token: 0x17000005 RID: 5
		// (get) Token: 0x06000015 RID: 21 RVA: 0x00002426 File Offset: 0x00000626
		// (set) Token: 0x06000016 RID: 22 RVA: 0x0000242E File Offset: 0x0000062E
		public Color SecondaryColor
		{
			get
			{
				return this._secondaryColor;
			}
			set
			{
				this._secondaryColor = value;
				base.Invalidate();
			}
		}

		// Token: 0x17000006 RID: 6
		// (get) Token: 0x06000017 RID: 23 RVA: 0x0000243D File Offset: 0x0000063D
		// (set) Token: 0x06000018 RID: 24 RVA: 0x00002445 File Offset: 0x00000645
		public int BorderSize
		{
			get
			{
				return this._borderSize;
			}
			set
			{
				this._borderSize = value;
				base.Invalidate();
			}
		}

		// Token: 0x17000007 RID: 7
		// (get) Token: 0x06000019 RID: 25 RVA: 0x00002454 File Offset: 0x00000654
		// (set) Token: 0x0600001A RID: 26 RVA: 0x0000245C File Offset: 0x0000065C
		public bool ChangeCursor
		{
			get
			{
				return this._ChangeCursor;
			}
			set
			{
				this._ChangeCursor = value;
				base.Invalidate();
			}
		}

		// Token: 0x0600001B RID: 27 RVA: 0x0000246C File Offset: 0x0000066C
		protected void SetTheme()
		{
			Fonts.Load();
			base.SetStyle(ControlStyles.UserPaint | ControlStyles.SupportsTransparentBackColor, true);
			this.DoubleBuffered = true;
			this.BackColor = Color.FromArgb(18, 18, 18);
			this.ForeColor = Color.White;
			this.Font = Fonts.GetFont(Config.Design.Font);
		}

		// Token: 0x0600001C RID: 28 RVA: 0x000024BD File Offset: 0x000006BD
		protected override void OnTextChanged(EventArgs e)
		{
			base.OnTextChanged(e);
			base.Invalidate();
		}

		// Token: 0x0600001D RID: 29 RVA: 0x000024CC File Offset: 0x000006CC
		protected override void OnMouseEnter(EventArgs e)
		{
			base.OnMouseEnter(e);
			this.State = (base.Enabled ? ThemedControl.MouseState.Over : ThemedControl.MouseState.Block);
			if (this.ChangeCursor)
			{
				this.Cursor = (base.Enabled ? Cursors.Hand : Cursors.Default);
			}
			base.Invalidate();
		}

		// Token: 0x0600001E RID: 30 RVA: 0x0000251A File Offset: 0x0000071A
		protected override void OnMouseLeave(EventArgs e)
		{
			base.OnMouseLeave(e);
			this.State = (base.Enabled ? ThemedControl.MouseState.None : ThemedControl.MouseState.Block);
			this.Cursor = Cursors.Default;
			base.Invalidate();
		}

		// Token: 0x0600001F RID: 31 RVA: 0x00002546 File Offset: 0x00000746
		protected override void OnMouseDown(MouseEventArgs e)
		{
			base.OnMouseDown(e);
			this.State = (base.Enabled ? ThemedControl.MouseState.Down : ThemedControl.MouseState.Block);
			base.Invalidate();
		}

		// Token: 0x06000020 RID: 32 RVA: 0x00002567 File Offset: 0x00000767
		protected override void OnMouseUp(MouseEventArgs e)
		{
			base.OnMouseUp(e);
			this.State = (base.Enabled ? ThemedControl.MouseState.Over : ThemedControl.MouseState.Block);
			base.Invalidate();
		}

		// Token: 0x06000021 RID: 33 RVA: 0x00002588 File Offset: 0x00000788
		protected override void OnEnabledChanged(EventArgs e)
		{
			base.OnEnabledChanged(e);
			this.State = (base.Enabled ? ThemedControl.MouseState.None : ThemedControl.MouseState.Block);
		}

		// Token: 0x06000022 RID: 34 RVA: 0x000025A3 File Offset: 0x000007A3
		protected override void OnPaint(PaintEventArgs e)
		{
			base.OnPaint(e);
			e.Graphics.SmoothingMode = SmoothingMode.AntiAlias;
			e.Graphics.CompositingQuality = CompositingQuality.HighQuality;
			e.Graphics.TextRenderingHint = TextRenderingHint.AntiAliasGridFit;
		}

		// Token: 0x04000002 RID: 2
		private int _CornerRadius = 18;

		// Token: 0x04000003 RID: 3
		private float _Rotation = 90f;

		// Token: 0x04000004 RID: 4
		private Color _primaryColor = Config.Design.Primary;

		// Token: 0x04000005 RID: 5
		private Color _secondaryColor = Config.Design.Secondary;

		// Token: 0x04000006 RID: 6
		private int _borderSize = 1;

		// Token: 0x04000007 RID: 7
		private bool _ChangeCursor = true;

		// Token: 0x02000016 RID: 22
		public enum MouseState : byte
		{
			// Token: 0x04000035 RID: 53
			None,
			// Token: 0x04000036 RID: 54
			Over,
			// Token: 0x04000037 RID: 55
			Down,
			// Token: 0x04000038 RID: 56
			Block
		}
	}
}
