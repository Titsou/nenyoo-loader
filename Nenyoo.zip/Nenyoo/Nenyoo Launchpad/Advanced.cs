﻿using System;
using System.Collections.Generic;
using System.IO;

namespace NenyooLaunchpad
{
	// Token: 0x02000004 RID: 4
	internal class Advanced
	{
		// Token: 0x06000009 RID: 9 RVA: 0x00002294 File Offset: 0x00000494
		public static string[] GetListOfLibraries()
		{
			List<string> list = new List<string>();
			foreach (string text in Directory.GetFiles(IO.GetWorkingPath()))
			{
				if (text.Contains(Config.General.LibraryName) && text.EndsWith(".dll"))
				{
					list.Add(text);
				}
			}
			return list.ToArray();
		}
	}
}
