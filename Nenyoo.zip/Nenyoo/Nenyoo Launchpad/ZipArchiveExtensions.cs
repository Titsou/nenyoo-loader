﻿using System;
using System.IO;
using System.IO.Compression;

// Token: 0x02000003 RID: 3
internal static class ZipArchiveExtensions
{
	// Token: 0x06000008 RID: 8 RVA: 0x00002204 File Offset: 0x00000404
	public static void ExtractToDirectory(this ZipArchive archive, string destinationDirectoryName, bool overwrite)
	{
		if (!overwrite)
		{
			archive.ExtractToDirectory(destinationDirectoryName);
			return;
		}
		foreach (ZipArchiveEntry zipArchiveEntry in archive.Entries)
		{
			string text = Path.Combine(destinationDirectoryName, zipArchiveEntry.FullName);
			string directoryName = Path.GetDirectoryName(text);
			if (!Directory.Exists(directoryName))
			{
				Directory.CreateDirectory(directoryName);
			}
			if (zipArchiveEntry.Name != "")
			{
				zipArchiveEntry.ExtractToFile(text, true);
			}
		}
	}
}
