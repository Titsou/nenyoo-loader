﻿using System;
using System.Diagnostics;
using System.Runtime.InteropServices;
using System.Text;

namespace NenyooLaunchpad
{
	// Token: 0x0200000F RID: 15
	internal class Memory
	{
		// Token: 0x0600006D RID: 109
		[DllImport("kernel32.dll")]
		private static extern IntPtr OpenProcess(int dwDesiredAccess, bool bInheritHandle, int dwProcessId);

		// Token: 0x0600006E RID: 110
		[DllImport("kernel32.dll", CharSet = CharSet.Auto)]
		private static extern IntPtr GetModuleHandle(string lpModuleName);

		// Token: 0x0600006F RID: 111
		[DllImport("kernel32", CharSet = CharSet.Ansi, ExactSpelling = true, SetLastError = true)]
		private static extern IntPtr GetProcAddress(IntPtr hModule, string procName);

		// Token: 0x06000070 RID: 112
		[DllImport("kernel32.dll", ExactSpelling = true, SetLastError = true)]
		private static extern IntPtr VirtualAllocEx(IntPtr hProcess, IntPtr lpAddress, uint dwSize, uint flAllocationType, uint flProtect);

		// Token: 0x06000071 RID: 113
		[DllImport("kernel32.dll", SetLastError = true)]
		private static extern bool WriteProcessMemory(IntPtr hProcess, IntPtr lpBaseAddress, byte[] lpBuffer, uint nSize, out UIntPtr lpNumberOfBytesWritten);

		// Token: 0x06000072 RID: 114
		[DllImport("kernel32.dll")]
		private static extern IntPtr CreateRemoteThread(IntPtr hProcess, IntPtr lpThreadAttributes, uint dwStackSize, IntPtr lpStartAddress, IntPtr lpParameter, uint dwCreationFlags, IntPtr lpThreadId);

		// Token: 0x06000073 RID: 115 RVA: 0x00004AF8 File Offset: 0x00002CF8
		public static bool IsGameRunning()
		{
			return Process.GetProcessesByName(Config.General.ProcessName).Length != 0;
		}

		// Token: 0x06000074 RID: 116 RVA: 0x00004B08 File Offset: 0x00002D08
		public static bool Inject(string DllPath)
		{
			if (!Memory.IsGameRunning())
			{
				return false;
			}
			Process process = Process.GetProcessesByName(Config.General.ProcessName)[0];
			IntPtr hProcess = Memory.OpenProcess(1082, false, process.Id);
			IntPtr procAddress = Memory.GetProcAddress(Memory.GetModuleHandle("kernel32.dll"), "LoadLibraryA");
			IntPtr intPtr = Memory.VirtualAllocEx(hProcess, IntPtr.Zero, (uint)((DllPath.Length + 1) * Marshal.SizeOf(typeof(char))), 12288U, 4U);
			UIntPtr uintPtr;
			Memory.WriteProcessMemory(hProcess, intPtr, Encoding.Default.GetBytes(DllPath), (uint)((DllPath.Length + 1) * Marshal.SizeOf(typeof(char))), out uintPtr);
			Memory.CreateRemoteThread(hProcess, IntPtr.Zero, 0U, procAddress, intPtr, 0U, IntPtr.Zero);
			return true;
		}

		// Token: 0x04000029 RID: 41
		private const int PROCESS_CREATE_THREAD = 2;

		// Token: 0x0400002A RID: 42
		private const int PROCESS_QUERY_INFORMATION = 1024;

		// Token: 0x0400002B RID: 43
		private const int PROCESS_VM_OPERATION = 8;

		// Token: 0x0400002C RID: 44
		private const int PROCESS_VM_WRITE = 32;

		// Token: 0x0400002D RID: 45
		private const int PROCESS_VM_READ = 16;

		// Token: 0x0400002E RID: 46
		private const uint MEM_COMMIT = 4096U;

		// Token: 0x0400002F RID: 47
		private const uint MEM_RESERVE = 8192U;

		// Token: 0x04000030 RID: 48
		private const uint PAGE_READWRITE = 4U;
	}
}
