﻿using System;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Drawing.Text;
using System.Windows.Forms;

namespace NenyooLaunchpad
{
	// Token: 0x0200000A RID: 10
	public class NenyooHeader : ThemedControl
	{
		// Token: 0x0600003C RID: 60 RVA: 0x00002E28 File Offset: 0x00001028
		public NenyooHeader()
		{
			base.SetTheme();
			base.Size = new Size(100, 30);
			this.ForeColor = Color.White;
			base.ChangeCursor = false;
			this.HeaderFont = Fonts.GetFont("Sharp Grotesk");
			this.SubtitleFont = Fonts.GetFont("Asher Punk");
		}

		// Token: 0x0600003D RID: 61 RVA: 0x00002E84 File Offset: 0x00001084
		protected override void OnPaint(PaintEventArgs e)
		{
			base.OnPaint(e);
			Graphics graphics = e.Graphics;
			int num = 1;
			int num2 = 8;
			string s = Config.General.MenuName.ToUpper();
			string s2 = "Launchpad";
			Rectangle rectangle = new Rectangle(-10, 0, base.Width, base.Height);
			graphics.SmoothingMode = SmoothingMode.AntiAlias;
			graphics.TextRenderingHint = TextRenderingHint.AntiAlias;
			graphics.DrawPath(new Pen(base.PrimaryColor, 2f), Drawing.GetStringPath(s, graphics.DpiY, new Rectangle(rectangle.X - num, num2 + rectangle.Y - num, rectangle.Width, rectangle.Height), this.HeaderFont, new StringFormat
			{
				Alignment = StringAlignment.Center,
				LineAlignment = StringAlignment.Center
			}));
			graphics.DrawPath(new Pen(base.SecondaryColor, 2f), Drawing.GetStringPath(s, graphics.DpiY, new Rectangle(rectangle.X + num, num2 + rectangle.Y + num, rectangle.Width, rectangle.Height), this.HeaderFont, new StringFormat
			{
				Alignment = StringAlignment.Center,
				LineAlignment = StringAlignment.Center
			}));
			graphics.FillPath(new SolidBrush(this.ForeColor), Drawing.GetStringPath(s, graphics.DpiY, new Rectangle(rectangle.X, num2 + rectangle.Y, rectangle.Width, rectangle.Height), this.HeaderFont, new StringFormat
			{
				Alignment = StringAlignment.Center,
				LineAlignment = StringAlignment.Center
			}));
			graphics.DrawPath(new Pen(base.PrimaryColor, 2f), Drawing.GetStringPath(s2, graphics.DpiY, new Rectangle(rectangle.X - num, num2 + rectangle.Y - num, rectangle.Width, rectangle.Height), this.SubtitleFont, new StringFormat
			{
				Alignment = StringAlignment.Far,
				LineAlignment = StringAlignment.Far
			}));
			graphics.DrawPath(new Pen(base.SecondaryColor, 2f), Drawing.GetStringPath(s2, graphics.DpiY, new Rectangle(rectangle.X + num, num2 + rectangle.Y + num, rectangle.Width, rectangle.Height), this.SubtitleFont, new StringFormat
			{
				Alignment = StringAlignment.Far,
				LineAlignment = StringAlignment.Far
			}));
			graphics.FillPath(new SolidBrush(this.ForeColor), Drawing.GetStringPath(s2, graphics.DpiY, new Rectangle(rectangle.X, num2 + rectangle.Y, rectangle.Width, rectangle.Height), this.SubtitleFont, new StringFormat
			{
				Alignment = StringAlignment.Far,
				LineAlignment = StringAlignment.Far
			}));
		}

		// Token: 0x04000014 RID: 20
		private Font HeaderFont;

		// Token: 0x04000015 RID: 21
		private Font SubtitleFont;
	}
}
