﻿using System;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Threading;
using System.Windows.Forms;

namespace NenyooLaunchpad
{
	// Token: 0x02000007 RID: 7
	public class NenyooForm : ContainerControl
	{
		// Token: 0x17000008 RID: 8
		// (get) Token: 0x06000024 RID: 36 RVA: 0x0000260F File Offset: 0x0000080F
		// (set) Token: 0x06000025 RID: 37 RVA: 0x00002617 File Offset: 0x00000817
		public int CornerRadius
		{
			get
			{
				return this._CornerRadius;
			}
			set
			{
				this._CornerRadius = value;
				base.Invalidate();
			}
		}

		// Token: 0x17000009 RID: 9
		// (get) Token: 0x06000026 RID: 38 RVA: 0x00002626 File Offset: 0x00000826
		// (set) Token: 0x06000027 RID: 39 RVA: 0x0000262E File Offset: 0x0000082E
		public Color PrimaryColor
		{
			get
			{
				return this._primaryColor;
			}
			set
			{
				this._primaryColor = value;
				base.Invalidate();
			}
		}

		// Token: 0x1700000A RID: 10
		// (get) Token: 0x06000028 RID: 40 RVA: 0x0000263D File Offset: 0x0000083D
		// (set) Token: 0x06000029 RID: 41 RVA: 0x00002645 File Offset: 0x00000845
		public Color SecondaryColor
		{
			get
			{
				return this._secondaryColor;
			}
			set
			{
				this._secondaryColor = value;
				base.Invalidate();
			}
		}

		// Token: 0x1700000B RID: 11
		// (get) Token: 0x0600002A RID: 42 RVA: 0x00002654 File Offset: 0x00000854
		// (set) Token: 0x0600002B RID: 43 RVA: 0x0000265C File Offset: 0x0000085C
		public float Rotation
		{
			get
			{
				return this._Rotation;
			}
			set
			{
				this._Rotation = value;
				base.Invalidate();
			}
		}

		// Token: 0x0600002C RID: 44 RVA: 0x0000266C File Offset: 0x0000086C
		public NenyooForm()
		{
			base.SetStyle(ControlStyles.UserPaint | ControlStyles.SupportsTransparentBackColor, true);
			this.BackColor = Color.FromArgb(18, 18, 18);
			this.DoubleBuffered = true;
			this.P1 = new Pen(Color.FromArgb(35, 35, 35));
			this.P2 = new Pen(Color.FromArgb(60, 60, 60));
			new Thread(new ThreadStart(this.AnimateGradient)).Start();
		}

		// Token: 0x0600002D RID: 45 RVA: 0x00002726 File Offset: 0x00000926
		private void AnimateGradient()
		{
			for (;;)
			{
				this._angle += 1f;
				if (this._angle >= 360f)
				{
					this._angle = 0f;
				}
				base.Invalidate();
				Thread.Sleep(10);
			}
		}

		// Token: 0x0600002E RID: 46 RVA: 0x00002760 File Offset: 0x00000960
		protected override void OnPaint(PaintEventArgs e)
		{
			Graphics graphics = e.Graphics;
			graphics.Clear(Color.Fuchsia);
			graphics.FillPath(new SolidBrush(this.BackColor), Drawing.CreateRounded(new Rectangle(0, 0, base.Width - 1, base.Height - 1), this.CornerRadius));
			ColorBlend colorBlend = new ColorBlend();
			colorBlend.Colors = new Color[]
			{
				this.PrimaryColor,
				this.SecondaryColor
			};
			colorBlend.Positions = new float[]
			{
				0f,
				1f
			};
			graphics.SmoothingMode = SmoothingMode.HighQuality;
			LinearGradientBrush brush = new LinearGradientBrush(new Rectangle(0, 0, base.Width - 1, base.Height - 1), Color.Black, Color.White, this._angle)
			{
				InterpolationColors = colorBlend
			};
			graphics.DrawPath(new Pen(brush, 2f), Drawing.CreateRounded(new Rectangle(1, 1, base.Width - 3, base.Height - 3), this.CornerRadius));
			graphics.SmoothingMode = SmoothingMode.Default;
			graphics.DrawPath(Pens.Black, Drawing.CreateRounded(new Rectangle(0, 0, base.Width - 1, base.Height - 1), this.CornerRadius));
		}

		// Token: 0x0600002F RID: 47 RVA: 0x00002894 File Offset: 0x00000A94
		protected override void OnMouseDown(MouseEventArgs e)
		{
			base.OnMouseDown(e);
			if (e.Button == MouseButtons.Left & new Rectangle(0, 0, base.Width, this.MoveHeight).Contains(e.Location))
			{
				this.Cap = true;
				this.MouseP = e.Location;
			}
		}

		// Token: 0x06000030 RID: 48 RVA: 0x000028EC File Offset: 0x00000AEC
		protected override void OnMouseMove(MouseEventArgs e)
		{
			base.OnMouseMove(e);
			if (this.Cap)
			{
				base.Parent.Location = new Point(Control.MousePosition.X - this.MouseP.X, Control.MousePosition.Y - this.MouseP.Y);
			}
		}

		// Token: 0x06000031 RID: 49 RVA: 0x0000294A File Offset: 0x00000B4A
		protected override void OnMouseUp(MouseEventArgs e)
		{
			base.OnMouseUp(e);
			this.Cap = false;
		}

		// Token: 0x06000032 RID: 50 RVA: 0x0000295A File Offset: 0x00000B5A
		protected override void OnCreateControl()
		{
			base.OnCreateControl();
			this.Dock = DockStyle.Fill;
			base.Parent.FindForm().FormBorderStyle = FormBorderStyle.None;
			base.Parent.FindForm().TransparencyKey = Color.Fuchsia;
		}

		// Token: 0x04000008 RID: 8
		private int _CornerRadius = 18;

		// Token: 0x04000009 RID: 9
		private Color _primaryColor = Config.Design.Primary;

		// Token: 0x0400000A RID: 10
		private Color _secondaryColor = Config.Design.Secondary;

		// Token: 0x0400000B RID: 11
		private float _Rotation = 90f;

		// Token: 0x0400000C RID: 12
		private readonly Pen P1;

		// Token: 0x0400000D RID: 13
		private readonly Pen P2;

		// Token: 0x0400000E RID: 14
		private Point MouseP = new Point(0, 0);

		// Token: 0x0400000F RID: 15
		private bool Cap;

		// Token: 0x04000010 RID: 16
		private readonly int MoveHeight = 200;

		// Token: 0x04000011 RID: 17
		private float _angle;
	}
}
