﻿namespace NenyooLaunchpad
{
	// Token: 0x0200000D RID: 13
	public partial class FormLaunchpad : global::System.Windows.Forms.Form
	{
		// Token: 0x06000057 RID: 87 RVA: 0x000038C7 File Offset: 0x00001AC7
		protected override void Dispose(bool disposing)
		{
			if (disposing && this.components != null)
			{
				this.components.Dispose();
			}
			base.Dispose(disposing);
		}

		// Token: 0x06000058 RID: 88 RVA: 0x000038E8 File Offset: 0x00001AE8
		private void InitializeComponent()
		{
			this.components = new global::System.ComponentModel.Container();
			global::System.ComponentModel.ComponentResourceManager componentResourceManager = new global::System.ComponentModel.ComponentResourceManager(typeof(global::NenyooLaunchpad.FormLaunchpad));
			this.TimerGameRunning = new global::System.Windows.Forms.Timer(this.components);
			this.TimerInjected = new global::System.Windows.Forms.Timer(this.components);
			this.TimerAutoInject = new global::System.Windows.Forms.Timer(this.components);
			this.nenyooForm1 = new global::NenyooLaunchpad.NenyooForm();
			this.LblStatus = new global::NenyooLaunchpad.NenyooLabel();
			this.nenyooHeader1 = new global::NenyooLaunchpad.NenyooHeader();
			this.ChkScriptHook = new global::NenyooLaunchpad.NenyooToggle();
			this.ChkAuto = new global::NenyooLaunchpad.NenyooToggle();
			this.ComboLaunchType = new global::System.Windows.Forms.ComboBox();
			this.nenyooButton1 = new global::NenyooLaunchpad.NenyooButton();
			this.BtnFolder = new global::NenyooLaunchpad.NenyooButton();
			this.BtnUpdate = new global::NenyooLaunchpad.NenyooButton();
			this.BtnInject = new global::NenyooLaunchpad.NenyooButton();
			this.BtnLaunch = new global::NenyooLaunchpad.NenyooButton();
			this.nenyooForm1.SuspendLayout();
			base.SuspendLayout();
			this.TimerGameRunning.Tick += new global::System.EventHandler(this.OnTickGameRunning);
			this.TimerInjected.Tick += new global::System.EventHandler(this.OnTickInjected);
			this.TimerAutoInject.Tick += new global::System.EventHandler(this.OnTickAutoInject);
			this.nenyooForm1.BackColor = global::System.Drawing.Color.FromArgb(18, 18, 18);
			this.nenyooForm1.Controls.Add(this.LblStatus);
			this.nenyooForm1.Controls.Add(this.nenyooHeader1);
			this.nenyooForm1.Controls.Add(this.ChkScriptHook);
			this.nenyooForm1.Controls.Add(this.ChkAuto);
			this.nenyooForm1.Controls.Add(this.ComboLaunchType);
			this.nenyooForm1.Controls.Add(this.nenyooButton1);
			this.nenyooForm1.Controls.Add(this.BtnFolder);
			this.nenyooForm1.Controls.Add(this.BtnUpdate);
			this.nenyooForm1.Controls.Add(this.BtnInject);
			this.nenyooForm1.Controls.Add(this.BtnLaunch);
			this.nenyooForm1.CornerRadius = 18;
			this.nenyooForm1.Dock = global::System.Windows.Forms.DockStyle.Fill;
			this.nenyooForm1.Location = new global::System.Drawing.Point(0, 0);
			this.nenyooForm1.Name = "nenyooForm1";
			this.nenyooForm1.PrimaryColor = global::System.Drawing.Color.FromArgb(232, 90, 175);
			this.nenyooForm1.Rotation = 90f;
			this.nenyooForm1.SecondaryColor = global::System.Drawing.Color.FromArgb(37, 87, 179);
			this.nenyooForm1.Size = new global::System.Drawing.Size(304, 369);
			this.nenyooForm1.TabIndex = 6;
			this.nenyooForm1.Text = "1";
			this.LblStatus.Anchor = (global::System.Windows.Forms.AnchorStyles.Bottom | global::System.Windows.Forms.AnchorStyles.Left);
			this.LblStatus.BackColor = global::System.Drawing.Color.FromArgb(18, 18, 18);
			this.LblStatus.BorderSize = 1;
			this.LblStatus.ChangeCursor = false;
			this.LblStatus.CornerRadius = 18;
			this.LblStatus.Font = new global::System.Drawing.Font("Segoe UI", 9f);
			this.LblStatus.ForeColor = global::System.Drawing.Color.White;
			this.LblStatus.Location = new global::System.Drawing.Point(12, 343);
			this.LblStatus.Name = "LblStatus";
			this.LblStatus.PrimaryColor = global::System.Drawing.Color.FromArgb(40, 5, 255);
			this.LblStatus.Rotation = 90f;
			this.LblStatus.SecondaryColor = global::System.Drawing.Color.FromArgb(255, 0, 158);
			this.LblStatus.Size = new global::System.Drawing.Size(262, 18);
			this.LblStatus.State = global::NenyooLaunchpad.ThemedControl.MouseState.None;
			this.LblStatus.TabIndex = 10;
			this.LblStatus.Text = "Ready to inject";
			this.nenyooHeader1.BackColor = global::System.Drawing.Color.FromArgb(18, 18, 18);
			this.nenyooHeader1.BorderSize = 1;
			this.nenyooHeader1.ChangeCursor = false;
			this.nenyooHeader1.CornerRadius = 18;
			this.nenyooHeader1.Font = new global::System.Drawing.Font("Segoe UI", 10f);
			this.nenyooHeader1.ForeColor = global::System.Drawing.Color.White;
			this.nenyooHeader1.Location = new global::System.Drawing.Point(29, 30);
			this.nenyooHeader1.Name = "nenyooHeader1";
			this.nenyooHeader1.PrimaryColor = global::System.Drawing.Color.FromArgb(232, 90, 175);
			this.nenyooHeader1.Rotation = 90f;
			this.nenyooHeader1.SecondaryColor = global::System.Drawing.Color.FromArgb(37, 87, 179);
			this.nenyooHeader1.Size = new global::System.Drawing.Size(245, 46);
			this.nenyooHeader1.State = global::NenyooLaunchpad.ThemedControl.MouseState.None;
			this.nenyooHeader1.TabIndex = 9;
			this.nenyooHeader1.Text = "nenyooHeader1";
			this.ChkScriptHook.BackColor = global::System.Drawing.Color.FromArgb(18, 18, 18);
			this.ChkScriptHook.BorderSize = 1;
			this.ChkScriptHook.ChangeCursor = true;
			this.ChkScriptHook.Checked = false;
			this.ChkScriptHook.CornerRadius = 8;
			this.ChkScriptHook.Font = new global::System.Drawing.Font("Segoe UI", 9f, global::System.Drawing.FontStyle.Regular, global::System.Drawing.GraphicsUnit.Point, 0);
			this.ChkScriptHook.ForeColor = global::System.Drawing.Color.White;
			this.ChkScriptHook.Location = new global::System.Drawing.Point(29, 185);
			this.ChkScriptHook.Name = "ChkScriptHook";
			this.ChkScriptHook.PrimaryColor = global::System.Drawing.Color.FromArgb(232, 90, 175);
			this.ChkScriptHook.Rotation = 55f;
			this.ChkScriptHook.SecondaryColor = global::System.Drawing.Color.FromArgb(37, 87, 179);
			this.ChkScriptHook.Size = new global::System.Drawing.Size(249, 18);
			this.ChkScriptHook.State = global::NenyooLaunchpad.ThemedControl.MouseState.None;
			this.ChkScriptHook.TabIndex = 8;
			this.ChkScriptHook.Text = "Enable ScriptHookV support";
			this.ChkScriptHook.CheckedChanged += new global::NenyooLaunchpad.NenyooToggle.CheckedChangedEventHandler(this.OnScriptHookCheckChanged);
			this.ChkAuto.BackColor = global::System.Drawing.Color.FromArgb(18, 18, 18);
			this.ChkAuto.BorderSize = 1;
			this.ChkAuto.ChangeCursor = true;
			this.ChkAuto.Checked = false;
			this.ChkAuto.CornerRadius = 8;
			this.ChkAuto.Font = new global::System.Drawing.Font("Segoe UI", 9f, global::System.Drawing.FontStyle.Regular, global::System.Drawing.GraphicsUnit.Point, 0);
			this.ChkAuto.ForeColor = global::System.Drawing.Color.White;
			this.ChkAuto.Location = new global::System.Drawing.Point(29, 159);
			this.ChkAuto.Name = "ChkAuto";
			this.ChkAuto.PrimaryColor = global::System.Drawing.Color.FromArgb(232, 90, 175);
			this.ChkAuto.Rotation = 55f;
			this.ChkAuto.SecondaryColor = global::System.Drawing.Color.FromArgb(37, 87, 179);
			this.ChkAuto.Size = new global::System.Drawing.Size(249, 18);
			this.ChkAuto.State = global::NenyooLaunchpad.ThemedControl.MouseState.None;
			this.ChkAuto.TabIndex = 8;
			this.ChkAuto.Text = "Automatically inject when game starts";
			this.ComboLaunchType.Anchor = (global::System.Windows.Forms.AnchorStyles.Bottom | global::System.Windows.Forms.AnchorStyles.Left);
			this.ComboLaunchType.BackColor = global::System.Drawing.Color.FromArgb(18, 18, 18);
			this.ComboLaunchType.DropDownHeight = 116;
			this.ComboLaunchType.DropDownStyle = global::System.Windows.Forms.ComboBoxStyle.DropDownList;
			this.ComboLaunchType.FlatStyle = global::System.Windows.Forms.FlatStyle.Flat;
			this.ComboLaunchType.Font = new global::System.Drawing.Font("Segoe UI", 9.25f);
			this.ComboLaunchType.ForeColor = global::System.Drawing.Color.White;
			this.ComboLaunchType.FormattingEnabled = true;
			this.ComboLaunchType.IntegralHeight = false;
			this.ComboLaunchType.ItemHeight = 15;
			this.ComboLaunchType.Items.AddRange(new object[]
			{
				"Epic Games",
				"Steam",
				"Rockstar"
			});
			this.ComboLaunchType.Location = new global::System.Drawing.Point(106, 380);
			this.ComboLaunchType.Name = "ComboLaunchType";
			this.ComboLaunchType.Size = new global::System.Drawing.Size(147, 23);
			this.ComboLaunchType.TabIndex = 4;
			this.ComboLaunchType.SelectedIndexChanged += new global::System.EventHandler(this.OnComboLaunchIndexChanged);
			this.nenyooButton1.BackColor = global::System.Drawing.Color.FromArgb(18, 18, 18);
			this.nenyooButton1.BorderSize = 1;
			this.nenyooButton1.ChangeCursor = true;
			this.nenyooButton1.CornerRadius = 12;
			this.nenyooButton1.Font = new global::System.Drawing.Font("Segoe UI", 9f);
			this.nenyooButton1.ForeColor = global::System.Drawing.Color.White;
			this.nenyooButton1.Location = new global::System.Drawing.Point(29, 289);
			this.nenyooButton1.Name = "nenyooButton1";
			this.nenyooButton1.PrimaryColor = global::System.Drawing.Color.FromArgb(232, 90, 175);
			this.nenyooButton1.Rotation = 55f;
			this.nenyooButton1.SecondaryColor = global::System.Drawing.Color.FromArgb(37, 87, 179);
			this.nenyooButton1.Size = new global::System.Drawing.Size(245, 30);
			this.nenyooButton1.State = global::NenyooLaunchpad.ThemedControl.MouseState.None;
			this.nenyooButton1.TabIndex = 7;
			this.nenyooButton1.Text = "Exit";
			this.nenyooButton1.Click += new global::System.EventHandler(this.OnClickExit);
			this.BtnFolder.BackColor = global::System.Drawing.Color.FromArgb(18, 18, 18);
			this.BtnFolder.BorderSize = 1;
			this.BtnFolder.ChangeCursor = true;
			this.BtnFolder.CornerRadius = 12;
			this.BtnFolder.Font = new global::System.Drawing.Font("Segoe UI", 9f);
			this.BtnFolder.ForeColor = global::System.Drawing.Color.White;
			this.BtnFolder.Location = new global::System.Drawing.Point(29, 252);
			this.BtnFolder.Name = "BtnFolder";
			this.BtnFolder.PrimaryColor = global::System.Drawing.Color.FromArgb(232, 90, 175);
			this.BtnFolder.Rotation = 55f;
			this.BtnFolder.SecondaryColor = global::System.Drawing.Color.FromArgb(37, 87, 179);
			this.BtnFolder.Size = new global::System.Drawing.Size(245, 30);
			this.BtnFolder.State = global::NenyooLaunchpad.ThemedControl.MouseState.None;
			this.BtnFolder.TabIndex = 6;
			this.BtnFolder.Text = "Open Nenyoo folder";
			this.BtnFolder.Click += new global::System.EventHandler(this.OnClickFolder);
			this.BtnUpdate.BackColor = global::System.Drawing.Color.FromArgb(18, 18, 18);
			this.BtnUpdate.BorderSize = 1;
			this.BtnUpdate.ChangeCursor = true;
			this.BtnUpdate.CornerRadius = 12;
			this.BtnUpdate.Font = new global::System.Drawing.Font("Segoe UI", 9f);
			this.BtnUpdate.ForeColor = global::System.Drawing.Color.White;
			this.BtnUpdate.Location = new global::System.Drawing.Point(29, 215);
			this.BtnUpdate.Name = "BtnUpdate";
			this.BtnUpdate.PrimaryColor = global::System.Drawing.Color.FromArgb(232, 90, 175);
			this.BtnUpdate.Rotation = 55f;
			this.BtnUpdate.SecondaryColor = global::System.Drawing.Color.FromArgb(37, 87, 179);
			this.BtnUpdate.Size = new global::System.Drawing.Size(245, 30);
			this.BtnUpdate.State = global::NenyooLaunchpad.ThemedControl.MouseState.None;
			this.BtnUpdate.TabIndex = 6;
			this.BtnUpdate.Text = "Check for updates";
			this.BtnUpdate.Click += new global::System.EventHandler(this.OnClickUpdate);
			this.BtnInject.BackColor = global::System.Drawing.Color.FromArgb(18, 18, 18);
			this.BtnInject.BorderSize = 1;
			this.BtnInject.ChangeCursor = true;
			this.BtnInject.CornerRadius = 12;
			this.BtnInject.Font = new global::System.Drawing.Font("Segoe UI", 10f);
			this.BtnInject.ForeColor = global::System.Drawing.Color.White;
			this.BtnInject.Location = new global::System.Drawing.Point(29, 96);
			this.BtnInject.Name = "BtnInject";
			this.BtnInject.PrimaryColor = global::System.Drawing.Color.FromArgb(232, 90, 175);
			this.BtnInject.Rotation = 55f;
			this.BtnInject.SecondaryColor = global::System.Drawing.Color.FromArgb(37, 87, 179);
			this.BtnInject.Size = new global::System.Drawing.Size(245, 50);
			this.BtnInject.State = global::NenyooLaunchpad.ThemedControl.MouseState.None;
			this.BtnInject.TabIndex = 7;
			this.BtnInject.Text = "Inject";
			this.BtnInject.Click += new global::System.EventHandler(this.OnClickInject);
			this.BtnLaunch.BackColor = global::System.Drawing.Color.FromArgb(18, 18, 18);
			this.BtnLaunch.BorderSize = 1;
			this.BtnLaunch.ChangeCursor = true;
			this.BtnLaunch.CornerRadius = 12;
			this.BtnLaunch.Font = new global::System.Drawing.Font("Segoe UI", 10f);
			this.BtnLaunch.ForeColor = global::System.Drawing.Color.White;
			this.BtnLaunch.Location = new global::System.Drawing.Point(29, 96);
			this.BtnLaunch.Name = "BtnLaunch";
			this.BtnLaunch.PrimaryColor = global::System.Drawing.Color.FromArgb(232, 90, 175);
			this.BtnLaunch.Rotation = 55f;
			this.BtnLaunch.SecondaryColor = global::System.Drawing.Color.FromArgb(37, 87, 179);
			this.BtnLaunch.Size = new global::System.Drawing.Size(245, 50);
			this.BtnLaunch.State = global::NenyooLaunchpad.ThemedControl.MouseState.None;
			this.BtnLaunch.TabIndex = 7;
			this.BtnLaunch.Text = "Launch";
			this.BtnLaunch.Click += new global::System.EventHandler(this.OnClickLaunch);
			base.AutoScaleMode = global::System.Windows.Forms.AutoScaleMode.None;
			this.BackColor = global::System.Drawing.Color.FromArgb(34, 34, 34);
			base.ClientSize = new global::System.Drawing.Size(304, 369);
			base.Controls.Add(this.nenyooForm1);
			this.Font = new global::System.Drawing.Font("Segoe UI", 9f, global::System.Drawing.FontStyle.Regular, global::System.Drawing.GraphicsUnit.Point, 0);
			base.FormBorderStyle = global::System.Windows.Forms.FormBorderStyle.None;
			
			base.MaximizeBox = false;
			base.Name = "FormLaunchpad";
			this.Text = "Nenyoo";
			base.TransparencyKey = global::System.Drawing.Color.Fuchsia;
			base.Load += new global::System.EventHandler(this.OnLoad);
			this.nenyooForm1.ResumeLayout(false);
			base.ResumeLayout(false);
		}

		// Token: 0x0400001A RID: 26
		private global::System.ComponentModel.IContainer components;

		// Token: 0x0400001B RID: 27
		private global::System.Windows.Forms.ComboBox ComboLaunchType;

		// Token: 0x0400001C RID: 28
		private global::System.Windows.Forms.Timer TimerGameRunning;

		// Token: 0x0400001D RID: 29
		private global::System.Windows.Forms.Timer TimerInjected;

		// Token: 0x0400001E RID: 30
		private global::System.Windows.Forms.Timer TimerAutoInject;

		// Token: 0x0400001F RID: 31
		private global::NenyooLaunchpad.NenyooForm nenyooForm1;

		// Token: 0x04000020 RID: 32
		private global::NenyooLaunchpad.NenyooButton BtnUpdate;

		// Token: 0x04000021 RID: 33
		private global::NenyooLaunchpad.NenyooButton BtnFolder;

		// Token: 0x04000022 RID: 34
		private global::NenyooLaunchpad.NenyooButton BtnLaunch;

		// Token: 0x04000023 RID: 35
		private global::NenyooLaunchpad.NenyooToggle ChkAuto;

		// Token: 0x04000024 RID: 36
		private global::NenyooLaunchpad.NenyooToggle ChkScriptHook;

		// Token: 0x04000025 RID: 37
		private global::NenyooLaunchpad.NenyooHeader nenyooHeader1;

		// Token: 0x04000026 RID: 38
		private global::NenyooLaunchpad.NenyooLabel LblStatus;

		// Token: 0x04000027 RID: 39
		private global::NenyooLaunchpad.NenyooButton BtnInject;

		// Token: 0x04000028 RID: 40
		private global::NenyooLaunchpad.NenyooButton nenyooButton1;
	}
}
