﻿using System;
using System.Drawing;

namespace NenyooLaunchpad
{
	// Token: 0x02000013 RID: 19
	internal class Config
	{
		// Token: 0x02000018 RID: 24
		public static class General
		{
			// Token: 0x04000039 RID: 57
			public static string MenuName = "Nenyoo";

			// Token: 0x0400003A RID: 58
			public static string ProcessName = "GTA5";

			// Token: 0x0400003B RID: 59
			public static string EpicProductId = "9d2d0eb64d5c44529cece33fe2a46482";

			// Token: 0x0400003C RID: 60
			public static string SteamProductId = "271590";

			// Token: 0x0400003D RID: 61
			public static string WorkingDirectoryName = "N3NYOOO";

			// Token: 0x0400003E RID: 62
			public static string LibraryName = "bin.dll";

			// Token: 0x0400003F RID: 63
			public static string VersionName = "version.txt";
		}

		// Token: 0x02000019 RID: 25
		public static class Endpoints
		{
			// Token: 0x04000040 RID: 64
			public static string LibraryUrl = "https://raw.githubusercontent.com/navmodder/N3NY000-PUBLIC/main/Nenyooo.nen";

			// Token: 0x04000041 RID: 65
			public static string VersionUrl = "https://raw.githubusercontent.com/navmodder/N3NY000-PUBLIC/main/version.txt";

			// Token: 0x04000042 RID: 66
			public static string HookUrl = "https://raw.githubusercontent.com/navmodder/N3NY000-PUBLIC/main/ScriptHookV.dll";

			// Token: 0x04000043 RID: 67
			public static string DataUrl = "https://raw.githubusercontent.com/navmodder/N3NY000-PUBLIC/main/data.zip";
		}

		// Token: 0x0200001A RID: 26
		public static class Launch
		{
			// Token: 0x04000044 RID: 68
			public static int InjectionDelay = 15000;

			// Token: 0x04000045 RID: 69
			public static bool AdvancedMode = false;

			// Token: 0x04000046 RID: 70
			public static bool AutoLaunch = false;

			// Token: 0x04000047 RID: 71
			public static bool AutoInject = false;

			// Token: 0x04000048 RID: 72
			public static bool ForceUpdate = false;

			// Token: 0x04000049 RID: 73
			public static bool SilentMode = false;

			// Token: 0x0400004A RID: 74
			public static bool DebugMode = false;
		}

		// Token: 0x0200001B RID: 27
		public static class Design
		{
			// Token: 0x0400004B RID: 75
			public static Color Primary = Color.FromArgb(232, 90, 175);

			// Token: 0x0400004C RID: 76
			public static Color Secondary = Color.FromArgb(37, 87, 179);

			// Token: 0x0400004D RID: 77
			public static string Font = "Open Sans";

			// Token: 0x0400004E RID: 78
			public static float Rotation = 65f;
		}
	}
}
