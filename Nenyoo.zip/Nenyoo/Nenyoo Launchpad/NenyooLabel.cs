﻿using System;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Drawing.Text;
using System.Windows.Forms;

namespace NenyooLaunchpad
{
	// Token: 0x0200000B RID: 11
	public class NenyooLabel : ThemedControl
	{
		// Token: 0x0600003E RID: 62 RVA: 0x00003134 File Offset: 0x00001334
		public NenyooLabel()
		{
			base.SetTheme();
			base.ChangeCursor = false;
		}

		// Token: 0x0600003F RID: 63 RVA: 0x0000314C File Offset: 0x0000134C
		protected override void OnPaint(PaintEventArgs e)
		{
			base.OnPaint(e);
			Graphics graphics = e.Graphics;
			graphics.SmoothingMode = SmoothingMode.AntiAlias;
			graphics.TextRenderingHint = TextRenderingHint.AntiAlias;
			graphics.DrawString(this.Text, this.Font, new SolidBrush(base.Enabled ? this.ForeColor : Color.Black), new Rectangle(0, 0, base.Width - 1, base.Height - 1), new StringFormat
			{
				Alignment = StringAlignment.Near,
				LineAlignment = StringAlignment.Center
			});
		}
	}
}
