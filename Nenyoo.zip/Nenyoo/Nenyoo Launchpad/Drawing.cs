﻿using System;
using System.Drawing;
using System.Drawing.Drawing2D;

namespace NenyooLaunchpad
{
	// Token: 0x02000005 RID: 5
	public static class Drawing
	{
		// Token: 0x0600000B RID: 11 RVA: 0x000022F4 File Offset: 0x000004F4
		public static GraphicsPath CreateRounded(Rectangle r, int slope)
		{
			GraphicsPath graphicsPath = new GraphicsPath(FillMode.Winding);
			graphicsPath.AddArc(r.X, r.Y, slope, slope, 180f, 90f);
			graphicsPath.AddArc(r.Right - slope, r.Y, slope, slope, 270f, 90f);
			graphicsPath.AddArc(r.Right - slope, r.Bottom - slope, slope, slope, 0f, 90f);
			graphicsPath.AddArc(r.X, r.Bottom - slope, slope, slope, 90f, 90f);
			graphicsPath.CloseFigure();
			return graphicsPath;
		}

		// Token: 0x0600000C RID: 12 RVA: 0x00002398 File Offset: 0x00000598
		internal static GraphicsPath GetStringPath(string s, float dpi, RectangleF rect, Font font, StringFormat format)
		{
			GraphicsPath graphicsPath = new GraphicsPath();
			float emSize = dpi * font.SizeInPoints / 72f;
			graphicsPath.AddString(s, font.FontFamily, (int)font.Style, emSize, rect, format);
			return graphicsPath;
		}
	}
}
