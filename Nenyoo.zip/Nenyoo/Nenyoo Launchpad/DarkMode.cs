﻿using System;
using System.Drawing;
using System.Runtime.InteropServices;
using System.Windows.Forms;
using Microsoft.Win32;

// Token: 0x02000002 RID: 2
internal static class DarkMode
{
	// Token: 0x06000001 RID: 1
	[DllImport("dwmapi.dll")]
	private static extern int DwmSetWindowAttribute(IntPtr hwnd, int attr, ref int attrValue, int attrSize);

	// Token: 0x06000002 RID: 2 RVA: 0x00002048 File Offset: 0x00000248
	private static bool UseImmersiveDarkMode(IntPtr handle, bool enabled)
	{
		if (!DarkMode.IsWindows10OrGreater(17763))
		{
			return false;
		}
		int attr = DarkMode.IsWindows10OrGreater(18985) ? 20 : 19;
		int num = enabled ? 1 : 0;
		return DarkMode.DwmSetWindowAttribute(handle, attr, ref num, 4) == 0;
	}

	// Token: 0x06000003 RID: 3 RVA: 0x0000208B File Offset: 0x0000028B
	private static bool IsWindows10OrGreater(int build = -1)
	{
		return DarkMode.WindowsVersion() >= 10 && DarkMode.WindowsBuildNumber() >= build;
	}

	// Token: 0x06000004 RID: 4 RVA: 0x000020A4 File Offset: 0x000002A4
	private static int WindowsVersion()
	{
		int result;
		int.TryParse(Registry.LocalMachine.OpenSubKey("SOFTWARE\\Microsoft\\Windows NT\\CurrentVersion").GetValue("ProductName").ToString().Split(new char[]
		{
			' '
		})[1], out result);
		return result;
	}

	// Token: 0x06000005 RID: 5 RVA: 0x000020EC File Offset: 0x000002EC
	private static int WindowsBuildNumber()
	{
		int result;
		int.TryParse(Registry.LocalMachine.OpenSubKey("SOFTWARE\\Microsoft\\Windows NT\\CurrentVersion").GetValue("CurrentBuildNumber").ToString(), out result);
		return result;
	}

	// Token: 0x06000006 RID: 6 RVA: 0x00002120 File Offset: 0x00000320
	private static void SetButtonDarkMode(Control Control, bool Enabled = true)
	{
		Button button = (Button)Control;
		button.FlatStyle = (Enabled ? FlatStyle.Flat : FlatStyle.Standard);
		button.FlatAppearance.BorderSize = 1;
		button.FlatAppearance.BorderColor = (Enabled ? Color.FromArgb(255, 51, 51, 51) : Color.Empty);
		button.FlatAppearance.MouseOverBackColor = (Enabled ? Color.FromArgb(64, 64, 64) : Color.Empty);
		button.FlatAppearance.MouseDownBackColor = (Enabled ? Color.FromArgb(58, 58, 58) : Color.Empty);
		button.BackColor = (Enabled ? Color.FromArgb(41, 41, 41) : Color.FromKnownColor(KnownColor.Control));
		button.ForeColor = (Enabled ? Color.White : Color.FromKnownColor(KnownColor.ControlText));
	}

	// Token: 0x06000007 RID: 7 RVA: 0x000021E3 File Offset: 0x000003E3
	public static void SetDarkMode(this Control Control, bool Enabled = true)
	{
		DarkMode.UseImmersiveDarkMode(Control.Handle, Enabled);
		if (Control is Button)
		{
			DarkMode.SetButtonDarkMode(Control, Enabled);
		}
	}
}
