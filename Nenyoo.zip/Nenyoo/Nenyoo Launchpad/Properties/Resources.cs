﻿using System;
using System.CodeDom.Compiler;
using System.ComponentModel;
using System.Diagnostics;
using System.Globalization;
using System.Resources;
using System.Runtime.CompilerServices;

namespace NenyooLaunchpad.Properties
{
	// Token: 0x02000014 RID: 20
	[GeneratedCode("System.Resources.Tools.StronglyTypedResourceBuilder", "17.0.0.0")]
	[DebuggerNonUserCode]
	[CompilerGenerated]
	internal class Resources
	{
		// Token: 0x06000082 RID: 130 RVA: 0x00004EB6 File Offset: 0x000030B6
		internal Resources()
		{
		}

		// Token: 0x1700000D RID: 13
		// (get) Token: 0x06000083 RID: 131 RVA: 0x00004EBE File Offset: 0x000030BE
		[EditorBrowsable(EditorBrowsableState.Advanced)]
		internal static ResourceManager ResourceManager
		{
			get
			{
				if (Resources.resourceMan == null)
				{
					Resources.resourceMan = new ResourceManager("NenyooLaunchpad.Properties.Resources", typeof(Resources).Assembly);
				}
				return Resources.resourceMan;
			}
		}

		// Token: 0x1700000E RID: 14
		// (get) Token: 0x06000084 RID: 132 RVA: 0x00004EEA File Offset: 0x000030EA
		// (set) Token: 0x06000085 RID: 133 RVA: 0x00004EF1 File Offset: 0x000030F1
		[EditorBrowsable(EditorBrowsableState.Advanced)]
		internal static CultureInfo Culture
		{
			get
			{
				return Resources.resourceCulture;
			}
			set
			{
				Resources.resourceCulture = value;
			}
		}

		// Token: 0x1700000F RID: 15
		// (get) Token: 0x06000086 RID: 134 RVA: 0x00004EF9 File Offset: 0x000030F9
		internal static byte[] RudaSemiBold
		{
			get
			{
				return (byte[])Resources.ResourceManager.GetObject("RudaSemiBold", Resources.resourceCulture);
			}
		}

		// Token: 0x17000010 RID: 16
		// (get) Token: 0x06000087 RID: 135 RVA: 0x00004F14 File Offset: 0x00003114
		internal static byte[] OpenSansSemiBold
		{
			get
			{
				return (byte[])Resources.ResourceManager.GetObject("OpenSansSemiBold", Resources.resourceCulture);
			}
		}

		// Token: 0x17000011 RID: 17
		// (get) Token: 0x06000088 RID: 136 RVA: 0x00004F2F File Offset: 0x0000312F
		internal static byte[] AsherPunk
		{
			get
			{
				return (byte[])Resources.ResourceManager.GetObject("AsherPunk", Resources.resourceCulture);
			}
		}

		// Token: 0x17000012 RID: 18
		// (get) Token: 0x06000089 RID: 137 RVA: 0x00004F4A File Offset: 0x0000314A
		internal static byte[] SharpGroteskSmBold25
		{
			get
			{
				return (byte[])Resources.ResourceManager.GetObject("SharpGroteskSmBold25", Resources.resourceCulture);
			}
		}

		// Token: 0x04000031 RID: 49
		private static ResourceManager resourceMan;

		// Token: 0x04000032 RID: 50
		private static CultureInfo resourceCulture;
	}
}
