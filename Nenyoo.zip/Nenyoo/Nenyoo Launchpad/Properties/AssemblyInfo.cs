﻿using System;
using System.Diagnostics;
using System.Reflection;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;
using System.Runtime.Versioning;

[assembly: AssemblyVersion("2.0.0.0")]
[assembly: AssemblyTitle("Nenyoo Launchpad")]
[assembly: AssemblyDescription("Official Launchpad for Nenyoo")]
[assembly: AssemblyConfiguration("")]
[assembly: AssemblyCompany("Nenyoo")]
[assembly: AssemblyProduct("Nenyoo Launchpad")]
[assembly: AssemblyCopyright("Copyright (c) 2023 - 2024 bypass#1337.")]
[assembly: AssemblyTrademark("")]
[assembly: ComVisible(false)]
[assembly: Guid("8db0d0c8-23f6-4600-bad4-f5ab23b966d9")]
[assembly: AssemblyFileVersion("2.0.0.0")]
