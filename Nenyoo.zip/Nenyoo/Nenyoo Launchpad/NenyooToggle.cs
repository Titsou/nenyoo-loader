﻿using System;
using System.ComponentModel;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Windows.Forms;

namespace NenyooLaunchpad
{
	// Token: 0x02000009 RID: 9
	[DefaultEvent("CheckedChanged")]
	public class NenyooToggle : ThemedControl
	{
		// Token: 0x14000001 RID: 1
		// (add) Token: 0x06000035 RID: 53 RVA: 0x00002B34 File Offset: 0x00000D34
		// (remove) Token: 0x06000036 RID: 54 RVA: 0x00002B6C File Offset: 0x00000D6C
		public event NenyooToggle.CheckedChangedEventHandler CheckedChanged;

		// Token: 0x1700000C RID: 12
		// (get) Token: 0x06000037 RID: 55 RVA: 0x00002BA1 File Offset: 0x00000DA1
		// (set) Token: 0x06000038 RID: 56 RVA: 0x00002BA9 File Offset: 0x00000DA9
		public bool Checked
		{
			get
			{
				return this._Checked;
			}
			set
			{
				this._Checked = value;
				NenyooToggle.CheckedChangedEventHandler checkedChanged = this.CheckedChanged;
				if (checkedChanged != null)
				{
					checkedChanged(this);
				}
				base.Invalidate();
			}
		}

		// Token: 0x06000039 RID: 57 RVA: 0x00002BCA File Offset: 0x00000DCA
		public NenyooToggle()
		{
			base.SetTheme();
			base.Size = new Size(50, 20);
		}

		// Token: 0x0600003A RID: 58 RVA: 0x00002BE8 File Offset: 0x00000DE8
		protected override void OnPaint(PaintEventArgs e)
		{
			base.OnPaint(e);
			Graphics graphics = e.Graphics;
			GraphicsPath path = Drawing.CreateRounded(new Rectangle(0, 0, base.Width - 1, base.Height - 1), base.CornerRadius);
			graphics.Clear(this.BackColor);
			graphics.FillPath(new SolidBrush(this.BackColor), path);
			ColorBlend colorBlend = new ColorBlend();
			colorBlend.Colors = new Color[]
			{
				base.PrimaryColor,
				base.SecondaryColor
			};
			colorBlend.Positions = new float[]
			{
				0f,
				1f
			};
			LinearGradientBrush linearGradientBrush = new LinearGradientBrush(new Rectangle(0, 0, base.Height - 1, base.Height - 1), Color.Black, Color.White, base.Rotation);
			linearGradientBrush.InterpolationColors = colorBlend;
			graphics.DrawPath(new Pen(linearGradientBrush, (float)base.BorderSize), Drawing.CreateRounded(new Rectangle(1, 1, base.Height - 3, base.Height - 3), base.CornerRadius));
			graphics.DrawString(this.Text, this.Font, new SolidBrush(base.Enabled ? this.ForeColor : Color.FromArgb(40, Color.White)), new Rectangle(base.Height + 3, 2, base.Width - base.Height - 1, base.Height - 1), new StringFormat
			{
				Alignment = StringAlignment.Near,
				LineAlignment = StringAlignment.Center
			});
			if (this.Checked)
			{
				graphics.FillPath(linearGradientBrush, Drawing.CreateRounded(new Rectangle(1, 1, base.Height - 3, base.Height - 3), base.CornerRadius));
			}
			if (base.State == ThemedControl.MouseState.Over)
			{
				graphics.FillPath(new SolidBrush(Color.FromArgb(3, Color.White)), Drawing.CreateRounded(new Rectangle(1, 1, base.Height - 3, base.Height - 3), base.CornerRadius));
			}
			graphics.DrawPath(new Pen(this.BackColor, 2f), Drawing.CreateRounded(new Rectangle(2, 2, base.Height - 5, base.Height - 5), base.CornerRadius));
		}

		// Token: 0x0600003B RID: 59 RVA: 0x00002E07 File Offset: 0x00001007
		protected override void OnClick(EventArgs e)
		{
			base.OnClick(e);
			this.Checked = !this.Checked;
			base.Invalidate();
		}

		// Token: 0x04000013 RID: 19
		private bool _Checked;

		// Token: 0x02000017 RID: 23
		// (Invoke) Token: 0x0600008E RID: 142
		public delegate void CheckedChangedEventHandler(object sender);
	}
}
