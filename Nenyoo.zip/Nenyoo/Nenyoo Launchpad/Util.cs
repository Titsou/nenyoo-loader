﻿using System;
using System.IO;
using System.Security.Cryptography;

namespace NenyooLaunchpad
{
	// Token: 0x02000012 RID: 18
	internal class Util
	{
		// Token: 0x0600007D RID: 125 RVA: 0x00004DDC File Offset: 0x00002FDC
		public static string GetBetween(string strSource, string strStart, string strEnd)
		{
			if (strSource.Contains(strStart) && strSource.Contains(strEnd))
			{
				int num = strSource.IndexOf(strStart, 0) + strStart.Length;
				int num2 = strSource.IndexOf(strEnd, num);
				return strSource.Substring(num, num2 - num);
			}
			return string.Empty;
		}

		// Token: 0x0600007E RID: 126 RVA: 0x00004E24 File Offset: 0x00003024
		public static string GetFileSHA256(string filePath)
		{
			string result;
			using (SHA256 sha = SHA256.Create())
			{
				using (FileStream fileStream = File.OpenRead(filePath))
				{
					result = BitConverter.ToString(sha.ComputeHash(fileStream)).Replace("-", string.Empty).ToLowerInvariant();
				}
			}
			return result;
		}

		// Token: 0x0600007F RID: 127 RVA: 0x00004E94 File Offset: 0x00003094
		public static string TrimExtension(string FileName)
		{
			return FileName.Replace(".dll", string.Empty);
		}
	}
}
