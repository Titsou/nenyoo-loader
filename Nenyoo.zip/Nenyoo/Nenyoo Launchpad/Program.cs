﻿using System;
using System.Windows.Forms;

namespace NenyooLaunchpad
{
	// Token: 0x02000011 RID: 17
	internal static class Program
	{
		// Token: 0x0600007C RID: 124 RVA: 0x00004DC4 File Offset: 0x00002FC4
		[STAThread]
		private static void Main()
		{
			Application.EnableVisualStyles();
			Application.SetCompatibleTextRenderingDefault(false);
			Application.Run(new FormLaunchpad());
		}
	}
}
