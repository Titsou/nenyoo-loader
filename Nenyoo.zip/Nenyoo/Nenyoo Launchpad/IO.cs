﻿using System;
using System.Diagnostics;
using System.IO;
using System.Windows.Forms;
using Microsoft.Win32;

namespace NenyooLaunchpad
{
	// Token: 0x0200000E RID: 14
	internal class IO
	{
		// Token: 0x0600005A RID: 90 RVA: 0x00004826 File Offset: 0x00002A26
		public static string GetWorkingPath()
		{
			return Path.Combine("C:\\", Config.General.WorkingDirectoryName);
		}

		// Token: 0x0600005B RID: 91 RVA: 0x00004838 File Offset: 0x00002A38
		public static void CreateWorkingPath()
		{
			string workingPath = IO.GetWorkingPath();
			if (!Directory.Exists(workingPath))
			{
				Directory.CreateDirectory(workingPath);
			}
		}

		// Token: 0x0600005C RID: 92 RVA: 0x0000485A File Offset: 0x00002A5A
		public static string GetLibraryPath()
		{
			if (!Config.Launch.DebugMode)
			{
				return Path.Combine(IO.GetWorkingPath(), Config.General.LibraryName);
			}
			return Application.StartupPath.Replace(".exe", ".dll");
		}

		// Token: 0x0600005D RID: 93 RVA: 0x00004887 File Offset: 0x00002A87
		public static string GetVersionPath()
		{
			return Path.Combine(IO.GetWorkingPath(), Config.General.VersionName);
		}

		// Token: 0x0600005E RID: 94 RVA: 0x00004898 File Offset: 0x00002A98
		public static string GetLibraryVersion()
		{
			if (!File.Exists(IO.GetVersionPath()))
			{
				File.Create(IO.GetVersionPath()).Close();
			}
			return File.ReadAllText(IO.GetVersionPath());
		}

		// Token: 0x0600005F RID: 95 RVA: 0x000048BF File Offset: 0x00002ABF
		public static string GetLibraryHash()
		{
			return Util.GetFileSHA256(IO.GetLibraryPath());
		}

		// Token: 0x06000060 RID: 96 RVA: 0x000048CB File Offset: 0x00002ACB
		public static bool IsLibraryFound()
		{
			return File.Exists(IO.GetLibraryPath());
		}

		// Token: 0x06000061 RID: 97 RVA: 0x000048D7 File Offset: 0x00002AD7
		public static bool IsDataFound()
		{
			return File.Exists(Path.Combine("C:\\", Config.General.WorkingDirectoryName, "imgui.ini"));
		}

		// Token: 0x06000062 RID: 98 RVA: 0x000048F2 File Offset: 0x00002AF2
		public static bool IsScriptHookFound()
		{
			return File.Exists(Path.Combine(IO.GetGameInstallLocation(), "ScriptHookV.dll"));
		}

		// Token: 0x06000063 RID: 99 RVA: 0x00004908 File Offset: 0x00002B08
		public static string GetScriptHookPath()
		{
			return Path.Combine(IO.GetGameInstallLocation(), "ScriptHookV.dll");
		}

		// Token: 0x06000064 RID: 100 RVA: 0x0000491C File Offset: 0x00002B1C
		public static string CheckSteamInstall()
		{
			string name = "SOFTWARE\\WOW6432Node\\Rockstar Games\\GTAV";
			RegistryKey registryKey = Registry.LocalMachine.OpenSubKey(name);
			if (registryKey == null)
			{
				return string.Empty;
			}
			if (registryKey.GetValue("InstallFolderSteam") != null)
			{
				return registryKey.GetValue("InstallFolderSteam").ToString();
			}
			return string.Empty;
		}

		// Token: 0x06000065 RID: 101 RVA: 0x00004968 File Offset: 0x00002B68
		public static string CheckEpicInstall()
		{
			string name = "SOFTWARE\\WOW6432Node\\Rockstar Games\\Grand Theft Auto V";
			RegistryKey registryKey = Registry.LocalMachine.OpenSubKey(name);
			if (registryKey == null)
			{
				return string.Empty;
			}
			if (registryKey.GetValue("InstallFolderEpic") != null)
			{
				return registryKey.GetValue("InstallFolderEpic").ToString();
			}
			return string.Empty;
		}

		// Token: 0x06000066 RID: 102 RVA: 0x000049B4 File Offset: 0x00002BB4
		public static string CheckRockstarInstall()
		{
			string name = "SOFTWARE\\WOW6432Node\\Rockstar Games\\Grand Theft Auto V";
			RegistryKey registryKey = Registry.LocalMachine.OpenSubKey(name);
			if (registryKey == null)
			{
				return string.Empty;
			}
			if (registryKey.GetValue("InstallFolder") != null)
			{
				return registryKey.GetValue("InstallFolder").ToString();
			}
			return string.Empty;
		}

		// Token: 0x06000067 RID: 103 RVA: 0x00004A00 File Offset: 0x00002C00
		public static string GetGameInstallationLocation(int version)
		{
			string result = string.Empty;
			if (version == 0)
			{
				result = IO.CheckSteamInstall().Replace("GTAV", string.Empty);
			}
			else if (version == 1)
			{
				result = IO.CheckEpicInstall();
			}
			else if (version == 2)
			{
				result = IO.CheckRockstarInstall();
			}
			return result;
		}

		// Token: 0x06000068 RID: 104 RVA: 0x00004A44 File Offset: 0x00002C44
		public static string GetGameInstallLocation()
		{
			return IO.GetGameInstallationLocation(IO.GetInstalledGameVersion());
		}

		// Token: 0x06000069 RID: 105 RVA: 0x00004A50 File Offset: 0x00002C50
		public static string GetRockstarExePath()
		{
			return Path.Combine(IO.GetGameInstallationLocation(2), "PlayGTAV.exe");
		}

		// Token: 0x0600006A RID: 106 RVA: 0x00004A64 File Offset: 0x00002C64
		public static int GetInstalledGameVersion()
		{
			for (int i = 0; i < 3; i++)
			{
				if (File.Exists(Path.Combine(IO.GetGameInstallationLocation(i), "PlayGTAV.exe")))
				{
					return i;
				}
			}
			return -1;
		}

		// Token: 0x0600006B RID: 107 RVA: 0x00004A98 File Offset: 0x00002C98
		public static void Launch(int GameVersion)
		{
			string fileName = string.Empty;
			switch (GameVersion)
			{
			case 0:
				fileName = string.Format("steam://rungameid/{0}", Config.General.SteamProductId);
				break;
			case 1:
				fileName = string.Format("com.epicgames.launcher://apps/{0}?action=launch&silent=true", Config.General.EpicProductId);
				break;
			case 2:
				fileName = IO.GetRockstarExePath();
				break;
			}
			Process.Start(fileName);
		}
	}
}
