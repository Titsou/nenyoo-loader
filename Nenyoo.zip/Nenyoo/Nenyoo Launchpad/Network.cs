﻿using System;
using System.IO;
using System.IO.Compression;
using System.Net;

namespace NenyooLaunchpad
{
	// Token: 0x02000010 RID: 16
	internal class Network
	{
		// Token: 0x06000076 RID: 118 RVA: 0x00004BC8 File Offset: 0x00002DC8
		public static bool IsLibraryUpdated()
		{
			string text = IO.GetLibraryVersion().Trim();
			string b = text;
			using (WebClient webClient = new WebClient())
			{
				b = webClient.DownloadString(Config.Endpoints.VersionUrl).Trim();
			}
			return text == b;
		}

		// Token: 0x06000077 RID: 119 RVA: 0x00004C1C File Offset: 0x00002E1C
		public static bool GetUpdatedLibrary()
		{
			try
			{
				if (IO.IsLibraryFound())
				{
					File.Delete(IO.GetLibraryPath());
				}
				using (WebClient webClient = new WebClient())
				{
					webClient.DownloadFile(Config.Endpoints.LibraryUrl, IO.GetLibraryPath());
				}
			}
			catch
			{
				return false;
			}
			return true;
		}

		// Token: 0x06000078 RID: 120 RVA: 0x00004C84 File Offset: 0x00002E84
		public static void GetUpdatedDataV()
		{
			Network.GetUpdatedData();
		}

		// Token: 0x06000079 RID: 121 RVA: 0x00004C8C File Offset: 0x00002E8C
		public static bool GetUpdatedData()
		{
			try
			{
				string text = Path.Combine("C:\\", Config.General.WorkingDirectoryName, "data.zip");
				if (File.Exists(text))
				{
					File.Delete(text);
				}
				using (WebClient webClient = new WebClient())
				{
					try
					{
						webClient.DownloadFile(Config.Endpoints.DataUrl, text);
						webClient.DownloadFile(Config.Endpoints.VersionUrl, IO.GetVersionPath());
					}
					catch
					{
						return false;
					}
				}
				using (ZipArchive zipArchive = ZipFile.OpenRead(text))
				{
					zipArchive.ExtractToDirectory(IO.GetWorkingPath(), true);
				}
				File.Delete(text);
			}
			catch
			{
				return false;
			}
			return true;
		}

		// Token: 0x0600007A RID: 122 RVA: 0x00004D54 File Offset: 0x00002F54
		public static bool GetUpdatedHook()
		{
			try
			{
				if (IO.IsScriptHookFound())
				{
					File.Delete(IO.GetScriptHookPath());
				}
				using (WebClient webClient = new WebClient())
				{
					webClient.DownloadFile(Config.Endpoints.HookUrl, IO.GetScriptHookPath());
				}
			}
			catch
			{
				return false;
			}
			return true;
		}
	}
}
