﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Drawing.Text;
using System.Runtime.InteropServices;
using NenyooLaunchpad.Properties;

namespace NenyooLaunchpad
{
	// Token: 0x0200000C RID: 12
	internal class Fonts
	{
		// Token: 0x06000040 RID: 64
		[DllImport("gdi32.dll")]
		private static extern IntPtr AddFontMemResourceEx(IntPtr pbFont, uint cbFont, IntPtr pdv, [In] ref uint pcFonts);

		// Token: 0x06000041 RID: 65 RVA: 0x000031CE File Offset: 0x000013CE
		public static Font GetFont(string FontName)
		{
			if (!Fonts.List.ContainsKey(FontName))
			{
				return null;
			}
			return Fonts.List[FontName];
		}

		// Token: 0x06000042 RID: 66 RVA: 0x000031EC File Offset: 0x000013EC
		private static void LoadCustomFont(string FontName, byte[] FontData, float FontSize)
		{
			IntPtr intPtr = Marshal.AllocCoTaskMem(FontData.Length);
			Marshal.Copy(FontData, 0, intPtr, FontData.Length);
			Fonts._FontCollection.AddMemoryFont(intPtr, FontData.Length);
			uint num = 0U;
			Fonts.AddFontMemResourceEx(intPtr, (uint)FontData.Length, IntPtr.Zero, ref num);
			Marshal.FreeCoTaskMem(intPtr);
			if (Fonts.List.ContainsKey(FontName))
			{
				return;
			}
			Fonts.List.Add(FontName, new Font(Fonts._FontCollection.Families[0], FontSize));
		}

		// Token: 0x06000043 RID: 67 RVA: 0x0000325F File Offset: 0x0000145F
		public static void Load()
		{
			Fonts.LoadCustomFont("Sharp Grotesk", Resources.SharpGroteskSmBold25, 26f);
			Fonts.LoadCustomFont("Open Sans", Resources.OpenSansSemiBold, 8.75f);
			Fonts.LoadCustomFont("Asher Punk", Resources.AsherPunk, 21f);
		}

		// Token: 0x04000016 RID: 22
		private static readonly PrivateFontCollection _FontCollection = new PrivateFontCollection();

		// Token: 0x04000017 RID: 23
		private static readonly Dictionary<string, Font> List = new Dictionary<string, Font>();
	}
}
