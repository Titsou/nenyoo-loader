﻿using System;
using System.ComponentModel;
using System.Diagnostics;
using System.Drawing;
using System.IO;
using System.Threading;
using System.Windows.Forms;

namespace NenyooLaunchpad
{
	// Token: 0x0200000D RID: 13
	public partial class FormLaunchpad : Form
	{
		// Token: 0x06000046 RID: 70 RVA: 0x000032BB File Offset: 0x000014BB
		public FormLaunchpad()
		{
			Fonts.Load();
			this.InitializeComponent();
			this.SetDarkMode(true);
		}

		// Token: 0x06000047 RID: 71 RVA: 0x000032DC File Offset: 0x000014DC
		private void OnLoad(object sender, EventArgs e)
		{
			Control.CheckForIllegalCrossThreadCalls = false;
			this.GameVersion = IO.GetInstalledGameVersion();
			IO.CreateWorkingPath();
			this.HandleLaunchOptions();
			this.CheckLibrary();
			this.TimerGameRunning.Start();
			this.TimerInjected.Start();
			this.TimerAutoInject.Start();
			this.InvalidateAll();
		}

		// Token: 0x06000048 RID: 72 RVA: 0x00003333 File Offset: 0x00001533
		private void OnClickFolder(object sender, EventArgs e)
		{
			Process.Start("explorer.exe", IO.GetWorkingPath());
		}

		// Token: 0x06000049 RID: 73 RVA: 0x00003348 File Offset: 0x00001548
		private void OnClickUpdate(object sender, EventArgs e)
		{
			if (Network.IsLibraryUpdated())
			{
				this.SetStatus(string.Format("Up to date. ({0})", IO.GetLibraryVersion().Trim()));
				return;
			}
			if (Network.GetUpdatedData() && Network.GetUpdatedLibrary())
			{
				this.SetStatus("Build updated.");
				return;
			}
			this.SetStatus("Unable to update. Try again later.");
		}

		// Token: 0x0600004A RID: 74 RVA: 0x0000339C File Offset: 0x0000159C
		private void OnClickInject(object sender, EventArgs e)
		{
			this.Inject();
		}

		// Token: 0x0600004B RID: 75 RVA: 0x000033A4 File Offset: 0x000015A4
		private void OnClickLaunch(object sender, EventArgs e)
		{
			new Thread(delegate()
			{
				IO.Launch(this.GameVersion);
				this.BtnLaunch.Text = "Launching..";
				this.SetStatus("Launching..");
				Thread.Sleep(3000);
				this.InvalidateAll();
				this.SetStatus("Ready to inject.");
			})
			{
				IsBackground = true
			}.Start();
		}

		// Token: 0x0600004C RID: 76 RVA: 0x000033C4 File Offset: 0x000015C4
		private void OnTickGameRunning(object sender, EventArgs e)
		{
			bool flag = Memory.IsGameRunning();
			this.BtnLaunch.Visible = !flag;
			this.ComboLaunchType.Visible = !flag;
			this.BtnInject.Visible = flag;
			if (!flag)
			{
				this.TimerAutoInject.Start();
			}
			this.InvalidateAll();
		}

		// Token: 0x0600004D RID: 77 RVA: 0x00003415 File Offset: 0x00001615
		private void OnTickInjected(object sender, EventArgs e)
		{
			if (Memory.IsGameRunning())
			{
				return;
			}
			this.ChkAuto.Enabled = true;
		}

		// Token: 0x0600004E RID: 78 RVA: 0x0000342B File Offset: 0x0000162B
		private void OnTickAutoInject(object sender, EventArgs e)
		{
			if (!this.ChkAuto.Checked)
			{
				return;
			}
			if (!Memory.IsGameRunning())
			{
				return;
			}
			Thread.Sleep(Config.Launch.InjectionDelay);
			this.Inject();
			this.TimerAutoInject.Stop();
		}

		// Token: 0x0600004F RID: 79 RVA: 0x0000345E File Offset: 0x0000165E
		private void OnScriptHookCheckChanged(object sender)
		{
			if (this.ChkScriptHook.Checked && !IO.IsScriptHookFound())
			{
				Network.GetUpdatedHook();
				return;
			}
			if (!this.ChkScriptHook.Checked && IO.IsScriptHookFound())
			{
				File.Delete(IO.GetScriptHookPath());
			}
		}

		// Token: 0x06000050 RID: 80 RVA: 0x00003499 File Offset: 0x00001699
		private void OnComboLaunchIndexChanged(object sender, EventArgs e)
		{
			this.InvalidateAll();
		}

		// Token: 0x06000051 RID: 81 RVA: 0x000034A4 File Offset: 0x000016A4
		private void HandleLaunchOptions()
		{
			string[] commandLineArgs = Environment.GetCommandLineArgs();
			if (commandLineArgs.Length < 2)
			{
				return;
			}
			int num = -1;
			foreach (string text in commandLineArgs)
			{
				if (text == "-autoinject")
				{
					Config.Launch.AutoInject = true;
				}
				if (text == "-autolaunch")
				{
					Config.Launch.AutoLaunch = true;
				}
				if (text == "-update")
				{
					Config.Launch.ForceUpdate = true;
				}
				if (text == "-silent" && Config.Launch.AutoLaunch && Config.Launch.AutoInject)
				{
					Config.Launch.SilentMode = true;
				}
				if (text == "-debug")
				{
					Config.Launch.DebugMode = true;
				}
				if (text == "-delay")
				{
					Config.Launch.InjectionDelay += 10000;
				}
				for (int j = 0; j < 3; j++)
				{
					if (text.ToLower() == (new string[]
					{
						"-steam",
						"-epic",
						"-rockstar"
					})[j])
					{
						num = j;
					}
				}
			}
			this.ChkAuto.Checked = Config.Launch.AutoInject;
			this.GameVersion = ((num < 0) ? IO.GetInstalledGameVersion() : num);
			if (Config.Launch.AutoLaunch)
			{
				if (Config.Launch.SilentMode)
				{
					base.Opacity = 0.0;
					base.ShowInTaskbar = false;
					base.Hide();
				}
				if (num == -1)
				{
					MessageBox.Show("No game version specified. Please launch the game manually.", this.Text, MessageBoxButtons.OK, MessageBoxIcon.Hand);
					return;
				}
				IO.Launch(num);
			}
		}

		// Token: 0x06000052 RID: 82 RVA: 0x00003618 File Offset: 0x00001818
		private bool CheckLibrary()
		{
			if (!IO.IsLibraryFound())
			{
				this.SetStatus("Downloading library..");
				new Thread(new ThreadStart(Network.GetUpdatedDataV))
				{
					IsBackground = true,
					Priority = ThreadPriority.Lowest
				}.Start();
			}
			if (IO.IsLibraryFound() && !Config.Launch.ForceUpdate)
			{
				this.SetStatus("Ready to inject.");
				return true;
			}
			if (Network.GetUpdatedLibrary())
			{
				this.SetStatus("Ready to inject.");
				return true;
			}
			this.SetStatus("Error updating.");
			return false;
		}

		// Token: 0x06000053 RID: 83 RVA: 0x00003698 File Offset: 0x00001898
		private void Inject()
		{
			if (!this.CheckLibrary() && !Config.Launch.DebugMode)
			{
				return;
			}
			if (Memory.Inject(IO.GetLibraryPath()))
			{
				this.TimerAutoInject.Stop();
				if (!Config.Launch.SilentMode)
				{
					if (!this.Injected)
					{
						MessageBox.Show("Injected successfully!", this.Text, MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
					}
					this.Injected = true;
				}
			}
			if (Config.Launch.SilentMode)
			{
				Environment.Exit(0);
			}
		}

		// Token: 0x06000054 RID: 84 RVA: 0x00003704 File Offset: 0x00001904
		private void InvalidateAll()
		{
			foreach (object obj in this.nenyooForm1.Controls)
			{
				Control control = (Control)obj;
				if (control != this.nenyooHeader1)
				{
					control.Font = Fonts.GetFont(Config.Design.Font);
				}
				if (control is ThemedControl)
				{
					ThemedControl themedControl = (ThemedControl)control;
					themedControl.PrimaryColor = Config.Design.Primary;
					themedControl.SecondaryColor = Config.Design.Secondary;
					themedControl.Rotation = Config.Design.Rotation;
				}
			}
			this.nenyooForm1.PrimaryColor = Config.Design.Primary;
			this.nenyooForm1.SecondaryColor = Config.Design.Secondary;
			this.nenyooForm1.Rotation = Config.Design.Rotation;
			this.ChkScriptHook.Enabled = (IO.GetInstalledGameVersion() > -1 || this.GameVersion > -1);
			this.ChkScriptHook.Checked = IO.IsScriptHookFound();
			this.BtnInject.Text = string.Format("Inject {0}", Config.General.MenuName);
			this.BtnFolder.Text = string.Format("Open {0} folder", Config.General.MenuName);
			this.BtnInject.Enabled = Memory.IsGameRunning();
			this.BtnLaunch.Enabled = (IO.GetInstalledGameVersion() > -1 || this.GameVersion > -1);
			int gameVersion = this.GameVersion;
			string arg = (gameVersion == 0) ? "Steam" : ((gameVersion == 1) ? "Epic Games" : "Rockstar");
			this.BtnLaunch.Text = ((gameVersion == -1) ? "Game Not Found" : string.Format("Launch via {0}", arg));
		}

		// Token: 0x06000055 RID: 85 RVA: 0x000038AC File Offset: 0x00001AAC
		private void SetStatus(string status)
		{
			this.LblStatus.Text = status;
		}

		// Token: 0x06000056 RID: 86 RVA: 0x000038BA File Offset: 0x00001ABA
		private void OnClickExit(object sender, EventArgs e)
		{
			Application.Exit();
			Environment.Exit(0);
		}

		// Token: 0x04000018 RID: 24
		private int GameVersion = -1;

		// Token: 0x04000019 RID: 25
		private bool Injected;
	}
}
