﻿using System;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Windows.Forms;

namespace NenyooLaunchpad
{
	// Token: 0x02000008 RID: 8
	public class NenyooButton : ThemedControl
	{
		// Token: 0x06000033 RID: 51 RVA: 0x0000298F File Offset: 0x00000B8F
		public NenyooButton()
		{
			base.SetTheme();
			base.Size = new Size(100, 30);
		}

		// Token: 0x06000034 RID: 52 RVA: 0x000029AC File Offset: 0x00000BAC
		protected override void OnPaint(PaintEventArgs e)
		{
			base.OnPaint(e);
			Graphics graphics = e.Graphics;
			GraphicsPath path = Drawing.CreateRounded(new Rectangle(0, 0, base.Width - 1, base.Height - 1), base.CornerRadius);
			graphics.Clear(this.BackColor);
			graphics.FillPath(new SolidBrush(this.BackColor), path);
			if (base.State == ThemedControl.MouseState.Over)
			{
				graphics.FillPath(new SolidBrush(Color.FromArgb(1, Color.White)), path);
			}
			ColorBlend colorBlend = new ColorBlend();
			colorBlend.Colors = new Color[]
			{
				base.PrimaryColor,
				base.SecondaryColor
			};
			colorBlend.Positions = new float[]
			{
				0f,
				1f
			};
			graphics.DrawPath(new Pen(new LinearGradientBrush(new Rectangle(0, 0, base.Width - 1, base.Height - 1), Color.Black, Color.White, base.Rotation)
			{
				InterpolationColors = colorBlend
			}, (float)base.BorderSize), Drawing.CreateRounded(new Rectangle(1, 1, base.Width - 3, base.Height - 3), base.CornerRadius));
			graphics.DrawString(this.Text, this.Font, new SolidBrush(base.Enabled ? this.ForeColor : Color.FromArgb(40, Color.White)), new Rectangle(0, 2, base.Width - 1, base.Height - 1), new StringFormat
			{
				Alignment = StringAlignment.Center,
				LineAlignment = StringAlignment.Center
			});
		}
	}
}
